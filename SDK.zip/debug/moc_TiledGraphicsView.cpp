/****************************************************************************
** Meta object code from reading C++ file 'TiledGraphicsView.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/TiledGraphicsView.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'TiledGraphicsView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TiledGraphicsView_t {
    QByteArrayData data[24];
    char stringdata0[306];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TiledGraphicsView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TiledGraphicsView_t qt_meta_stringdata_TiledGraphicsView = {
    {
QT_MOC_LITERAL(0, 0, 17), // "TiledGraphicsView"
QT_MOC_LITERAL(1, 18, 16), // "sigGeometryDrawn"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 9), // "DrawShape"
QT_MOC_LITERAL(4, 46, 9), // "shapeType"
QT_MOC_LITERAL(5, 56, 12), // "QPainterPath"
QT_MOC_LITERAL(6, 69, 4), // "path"
QT_MOC_LITERAL(7, 74, 20), // "sigCursorInfoChanged"
QT_MOC_LITERAL(8, 95, 7), // "imgName"
QT_MOC_LITERAL(9, 103, 1), // "x"
QT_MOC_LITERAL(10, 105, 1), // "y"
QT_MOC_LITERAL(11, 107, 15), // "sigStatsUpdated"
QT_MOC_LITERAL(12, 123, 5), // "stats"
QT_MOC_LITERAL(13, 129, 23), // "sigContextMenuRequested"
QT_MOC_LITERAL(14, 153, 9), // "globalPos"
QT_MOC_LITERAL(15, 163, 21), // "QList<QGraphicsItem*>"
QT_MOC_LITERAL(16, 185, 15), // "itemsUnderMouse"
QT_MOC_LITERAL(17, 201, 18), // "sigDefectsSelected"
QT_MOC_LITERAL(18, 220, 23), // "QList<DefectShapeItem*>"
QT_MOC_LITERAL(19, 244, 15), // "selectedDefects"
QT_MOC_LITERAL(20, 260, 17), // "sigRegionExported"
QT_MOC_LITERAL(21, 278, 6), // "pixmap"
QT_MOC_LITERAL(22, 285, 10), // "resetToFit"
QT_MOC_LITERAL(23, 296, 9) // "updateHUD"

    },
    "TiledGraphicsView\0sigGeometryDrawn\0\0"
    "DrawShape\0shapeType\0QPainterPath\0path\0"
    "sigCursorInfoChanged\0imgName\0x\0y\0"
    "sigStatsUpdated\0stats\0sigContextMenuRequested\0"
    "globalPos\0QList<QGraphicsItem*>\0"
    "itemsUnderMouse\0sigDefectsSelected\0"
    "QList<DefectShapeItem*>\0selectedDefects\0"
    "sigRegionExported\0pixmap\0resetToFit\0"
    "updateHUD"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TiledGraphicsView[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   54,    2, 0x06 /* Public */,
       7,    3,   59,    2, 0x06 /* Public */,
      11,    1,   66,    2, 0x06 /* Public */,
      13,    2,   69,    2, 0x06 /* Public */,
      17,    1,   74,    2, 0x06 /* Public */,
      20,    1,   77,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      22,    0,   80,    2, 0x0a /* Public */,
      23,    0,   81,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5,    4,    6,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::Int,    8,    9,   10,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void, QMetaType::QPoint, 0x80000000 | 15,   14,   16,
    QMetaType::Void, 0x80000000 | 18,   19,
    QMetaType::Void, QMetaType::QPixmap,   21,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void TiledGraphicsView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TiledGraphicsView *_t = static_cast<TiledGraphicsView *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sigGeometryDrawn((*reinterpret_cast< DrawShape(*)>(_a[1])),(*reinterpret_cast< QPainterPath(*)>(_a[2]))); break;
        case 1: _t->sigCursorInfoChanged((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 2: _t->sigStatsUpdated((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->sigContextMenuRequested((*reinterpret_cast< QPoint(*)>(_a[1])),(*reinterpret_cast< QList<QGraphicsItem*>(*)>(_a[2]))); break;
        case 4: _t->sigDefectsSelected((*reinterpret_cast< QList<DefectShapeItem*>(*)>(_a[1]))); break;
        case 5: _t->sigRegionExported((*reinterpret_cast< QPixmap(*)>(_a[1]))); break;
        case 6: _t->resetToFit(); break;
        case 7: _t->updateHUD(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QGraphicsItem*> >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<DefectShapeItem*> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (TiledGraphicsView::*_t)(DrawShape , QPainterPath );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&TiledGraphicsView::sigGeometryDrawn)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (TiledGraphicsView::*_t)(QString , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&TiledGraphicsView::sigCursorInfoChanged)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (TiledGraphicsView::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&TiledGraphicsView::sigStatsUpdated)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (TiledGraphicsView::*_t)(QPoint , QList<QGraphicsItem*> );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&TiledGraphicsView::sigContextMenuRequested)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (TiledGraphicsView::*_t)(QList<DefectShapeItem*> );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&TiledGraphicsView::sigDefectsSelected)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (TiledGraphicsView::*_t)(QPixmap );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&TiledGraphicsView::sigRegionExported)) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject TiledGraphicsView::staticMetaObject = {
    { &QGraphicsView::staticMetaObject, qt_meta_stringdata_TiledGraphicsView.data,
      qt_meta_data_TiledGraphicsView,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *TiledGraphicsView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TiledGraphicsView::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_TiledGraphicsView.stringdata0))
        return static_cast<void*>(const_cast< TiledGraphicsView*>(this));
    return QGraphicsView::qt_metacast(_clname);
}

int TiledGraphicsView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void TiledGraphicsView::sigGeometryDrawn(DrawShape _t1, QPainterPath _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void TiledGraphicsView::sigCursorInfoChanged(QString _t1, int _t2, int _t3)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void TiledGraphicsView::sigStatsUpdated(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void TiledGraphicsView::sigContextMenuRequested(QPoint _t1, QList<QGraphicsItem*> _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void TiledGraphicsView::sigDefectsSelected(QList<DefectShapeItem*> _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void TiledGraphicsView::sigRegionExported(QPixmap _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
