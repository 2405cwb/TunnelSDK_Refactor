CONFIG += no_fixpath
QT = core sql gui widgets concurrent
        
        
      
        DEFINES -= UNICODE _UNICODE
